package com.example.sesau;

import java.io.Serializable;

public class Local implements Serializable {
    private int id;
    private String descricao;
    private String classificacao;
    private Double populacao;
    private String geolocal;
    private int ndistrito;
    private String endereco;

    public Local(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public Double getPopulacao() {
        return populacao;
    }

    public void setPopulacao(Double populacao) {
        this.populacao = populacao;
    }

    public String getGeolocal() {
        return geolocal;
    }

    public void setGeolocal(String geolocal) {
        this.geolocal = geolocal;
    }

    public int getNdistrito() {
        return ndistrito;
    }

    public void setNdistrito(int ndistrito) {
        this.ndistrito = ndistrito;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString(){
        return classificacao + " - " + descricao;
    }
}
