package com.example.sesau;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PainelLocal extends AppCompatActivity {
    private ListView listLocal;
    private Button btnNovoCadastro;
    private Local local;
    DBLocalHelper localHelper;
    ArrayList<Local> arrayListLocal;
    ArrayAdapter<Local> arrayAdapterLocal;
    private int id1,id2; //menu item
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listLocal = findViewById(R.id.listLocal);
        registerForContextMenu(listLocal);
        btnNovoCadastro = findViewById(R.id.btnNovoCadastro);
        btnNovoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(PainelLocal.this,CadastroLocal.class);
                startActivity(it);
            }
        });
        listLocal.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Local localEnviada = (Local) arrayAdapterLocal.getItem(position);
                Intent it = new Intent(PainelLocal.this,CadastroLocal.class);
                it.putExtra("chave_local",localEnviada);
                startActivity(it);
            }
        });
        listLocal.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView,View view, int position, long id){
                local = arrayAdapterLocal.getItem(position);
                return false;
            }
        });
    }
    public void preencheLista(){
        localHelper = new DBLocalHelper(PainelLocal.this);
        arrayListLocal = localHelper.selectAllLocal();
        localHelper.close();
        if(listLocal!=null){
            arrayAdapterLocal = new ArrayAdapter<Local>(PainelLocal.this,
                    android.R.layout.simple_list_item_1,arrayListLocal);
            listLocal.setAdapter(arrayAdapterLocal);
        }
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        MenuItem mDelete = menu.add(Menu.NONE, id1, 1,"Deleta Registro");
        MenuItem mSair = menu.add(Menu.NONE, id2, 2,"Cancela");
        mDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                long retornoBD;
                localHelper = new DBLocalHelper(PainelLocal.this);
                retornoBD = localHelper.deleteLocal(local);
                localHelper.close();
                if(retornoBD==-1){
                    alert("Erro de exclusão!");
                }
                else{
                    alert("Registro excluído com sucesso!");
                }
                preencheLista();
                return false;        }
        });
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    @Override
    protected void onResume(){
        super.onResume();
        preencheLista();
    }
    private void alert(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    }
}