package com.example.sesau;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBLocalHelper extends SQLiteOpenHelper{

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "local2.db";
    private static final String TABLE_NAME = "local";
    private static final String COLUM_ID = "id";
    private static final String COLUM_NDISTRITO = "ndistrito";
    private static final String COLUM_CLASSIFICACAO = "classificacao";
    private static final String COLUM_DESCRICAO = "descricao";
    private static final String COLUM_POPULACAO = "populacao";
    private static final String COLUM_GEOLOCAL = "geolocal";
    private static final String COLUM_ENDERECO = "endereco";
    SQLiteDatabase db;
    private static final String TABLE_CREATE = "create table local " +
            "(id integer primary key autoincrement, ndistrito integer not null, classificacao text, descricao text not null, populacao real, geolocal text, endereco text);";
    public DBLocalHelper(Context context){
        super(context, DATABASE_NAME,null,DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS "+TABLE_NAME;
        db.execSQL(query);
        onCreate(db);
    }
    public long insereLocal(Local l){
        long retornoBD;
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUM_NDISTRITO,l.getNdistrito());
        values.put(COLUM_CLASSIFICACAO,l.getClassificacao());
        values.put(COLUM_DESCRICAO,l.getDescricao());
        values.put(COLUM_POPULACAO,l.getPopulacao());
        values.put(COLUM_GEOLOCAL,l.getGeolocal());
        values.put(COLUM_ENDERECO,l.getEndereco());
        retornoBD=db.insert(TABLE_NAME,null,values);
        String res=Long.toString(retornoBD);
        Log.i("DBHelperLocal",res);
        db.close();
        return retornoBD;
    }
    public ArrayList<Local> selectAllLocal(){
        String[] coluns={COLUM_ID, COLUM_NDISTRITO, COLUM_CLASSIFICACAO, COLUM_DESCRICAO, COLUM_POPULACAO, COLUM_GEOLOCAL,COLUM_ENDERECO};
        Cursor cursor = getWritableDatabase().query(TABLE_NAME,
                coluns,null,null,null,
                null,"upper(descricao)",null);
        ArrayList<Local> listaLocal = new ArrayList<Local>();
        while(cursor.moveToNext()){
            Local l = new Local();
            l.setId(cursor.getInt(0));
            l.setNdistrito(cursor.getInt(1));
            l.setClassificacao(cursor.getString(2));
            l.setDescricao(cursor.getString(3));
            l.setPopulacao(cursor.getDouble(4));
            l.setGeolocal(cursor.getString(5));
            l.setEndereco(cursor.getString(6));
            listaLocal.add(l);
        }
        return listaLocal;
    }
    public long updateLocal(Local l){
        long retornoBD;
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUM_ID,l.getId());
        values.put(COLUM_NDISTRITO, l.getNdistrito());
        values.put(COLUM_CLASSIFICACAO,l.getClassificacao());
        values.put(COLUM_DESCRICAO,l.getDescricao());
        values.put(COLUM_POPULACAO, l.getPopulacao());
        values.put(COLUM_GEOLOCAL,l.getGeolocal());
        values.put(COLUM_ENDERECO,l.getEndereco());
        String[] args = {String.valueOf(l.getId())};
        retornoBD=db.update(TABLE_NAME,values,"id=?",args);
        db.close();
        return retornoBD;
    }
    public long deleteLocal(Local l){
        long retornoBD;
        db = this.getWritableDatabase();
        String[] args = {String.valueOf(l.getId())};
        retornoBD=db.delete(TABLE_NAME, COLUM_ID+"=?",args);
        return retornoBD;
    }
}
