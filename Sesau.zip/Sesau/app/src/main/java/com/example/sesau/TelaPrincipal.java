package com.example.sesau;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

public class TelaPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuprincipal, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id){
            case R.id.op_agenda:
                Intent ita=new Intent(TelaPrincipal.this, Agenda.class);
                startActivity(ita);
                return true;
            case R.id.op_local:
                Intent itl=new Intent(TelaPrincipal.this, LocalVisita.class);
                startActivity(itl);
                return true;
            case R.id.op_kit:
                Intent itk=new Intent(TelaPrincipal.this, Kit.class);
                startActivity(itk);
                return true;
            case R.id.op_sair:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}