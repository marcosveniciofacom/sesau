package com.example.sesau;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroLocal extends AppCompatActivity {

    private EditText edtDistrito, edtDescricao, edtClassificacao, edtPopulacao, edtGeolocal, edtEndereco;
    private Button btnVariavel;
    Local local, altLocal;
    DBLocalHelper localHelper;
    long retornoBD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_local);
        Intent it=getIntent();
        altLocal = (Local) it.getSerializableExtra("chave_local");
        local = new Local();
        localHelper = new DBLocalHelper(CadastroLocal.this);
        edtDistrito = findViewById(R.id.edtNdistrito);
        edtDescricao = findViewById(R.id.edtDescricao);
        edtClassificacao = findViewById(R.id.edtClassificacao);
        edtPopulacao = findViewById(R.id.edtPopulacao);
        edtGeolocal = findViewById(R.id.edtGeolocal);
        edtEndereco = findViewById(R.id.edtEndereco);
        btnVariavel = findViewById(R.id.btnVariavel);
        if(altLocal != null){
            btnVariavel.setText("ALTERAR");
            edtDistrito.setText(altLocal.getNdistrito()+"");
            edtClassificacao.setText(altLocal.getClassificacao());
            edtDescricao.setText(altLocal.getDescricao());
            edtPopulacao.setText(altLocal.getPopulacao()+"");
            edtGeolocal.setText(altLocal.getGeolocal());
            edtEndereco.setText(altLocal.getEndereco());
            local.setId(altLocal.getId());
        }
        else{
            btnVariavel.setText("SALVAR");
        }
        btnVariavel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String distrito = edtDistrito.getText().toString();
                String descricao = edtDescricao.getText().toString();
                String classificacao = edtClassificacao.getText().toString();
                String populacao = edtPopulacao.getText().toString();
                String geolocal = edtGeolocal.getText().toString();
                String endereco = edtEndereco.getText().toString();
                long retornoBD;
                local.setNdistrito(Integer.parseInt(distrito));
                local.setDescricao(descricao);
                local.setClassificacao(classificacao);
                local.setPopulacao(Double.parseDouble(populacao));
                local.setGeolocal(geolocal);
                local.setEndereco(endereco);
                if(btnVariavel.getText().toString().equals("SALVAR")) {
                    retornoBD=localHelper.insereLocal(local);
                    if(retornoBD==-1){
                        alert("Erro ao Cadastrar!");
                    }
                    else{
                        alert("Cadastro realizado com sucesso!");
                    }
                }else{
                    localHelper.updateLocal(local);
                    localHelper.close();
                }
                finish();
            }
        });
    }
    private void alert(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    }
}