package com.example.sesau;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroServidor extends AppCompatActivity {
    private DBServidorHelper helper=new DBServidorHelper(this);
    private EditText edtNome;
    private EditText edtEmail;
    private EditText edtTipo;
    private EditText edtUsuario;
    private EditText edtSenha;
    private EditText edtConfSenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_servidor);
        edtNome=findViewById(R.id.edtNome);
        edtEmail=findViewById(R.id.edtEmail);
        edtTipo=findViewById(R.id.edtTipo);
        edtUsuario=findViewById(R.id.edtUsuario);
        edtSenha=findViewById(R.id.edtSenha);
        edtConfSenha=findViewById(R.id.edtConfSenha);
    }
    public void cadastrar(View view) {
        String nome=edtNome.getText().toString();
        String email=edtEmail.getText().toString();
        String tp=edtTipo.getText().toString();
        String usr=edtUsuario.getText().toString();
        String senha=edtSenha.getText().toString();
        String confSenha=edtConfSenha.getText().toString();
        if(!senha.equals(confSenha)){
            Toast toast=Toast.makeText(CadastroServidor.this, "Senha difere da confirmação de senha!",Toast.LENGTH_SHORT);
            toast.show();
            edtSenha.setText("");
            edtConfSenha.setText("");
        }else{
            Servidor s = new Servidor();
            s.setNome(nome);
            s.setEmail(email);
            s.setTipo(tp);
            s.setUsuario(usr);
            s.setSenha(senha);
            helper.inserirServidor(s);
            Toast toast=Toast.makeText(CadastroServidor.this,
                    "Cadastro realizado com sucesso!",Toast.LENGTH_SHORT);
            toast.show();
            limpar();
        }
    }

    private void limpar() {
        edtNome.setText("");
        edtEmail.setText("");
        edtTipo.setText("");
        edtUsuario.setText("");
        edtSenha.setText("");
        edtConfSenha.setText("");
    }

    public void cancelar(View view) {
        finish();
    }
}